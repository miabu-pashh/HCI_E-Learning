import React from 'react'

const CoursePage = () => {
  return (
    <div>
      
    </div>
  )
}

export default CoursePage
