import React from 'react'

const CoursesPage = () => {
  return (
    <div>
    </div>
  )
}

export default CoursesPage
