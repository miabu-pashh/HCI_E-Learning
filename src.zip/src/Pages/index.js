import Home from './HomePage';
import Cart from './CartPage';
import Courses from './CoursesPage';
import SingleCoursePage from './SingleCoursePage';


export {Home, Courses, SingleCoursePage, Cart}

