export const PYTHON = "python";     
export const WEB_DEVELOPMENT = "web development";
export const DATA_SCIENCE = "data science";
export const AWS = "aws";
export const DESIGN = "design";
export const MARKETING = "marketing";

export const MATH = "math";
export const SCIENCE = "science";
export const ARTS_CRAFTS = "arts & crafts";
export const STORY_TIME = "story time";
export const BASIC_CODING = "basic coding";
export const NATURE_EXPLORATION = "nature exploration";
