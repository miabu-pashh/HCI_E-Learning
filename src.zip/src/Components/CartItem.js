import React from 'react'

const CartItem = () => {
  return (
    <div>
      This is Cart
      
    </div>
  )
}

export default CartItem
