import React from 'react'

const CategoriesList = () => {
  return (
    <div>
      {/* <h1>This is the course list Page</h1> */}
    </div>
  )
}

export default CategoriesList
